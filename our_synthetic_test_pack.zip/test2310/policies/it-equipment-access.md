# IT Equipment and Access Standard (IT-02)
Synthetic sample policy for the prototype.

## 1. Standard equipment
Office roles receive a laptop, headset and mobile authenticator. Operational roles receive a tablet or shared device as defined by their department.

## 2. Issue timelines
IT orders equipment 5 days before the start date or move date. Equipment is issued within 1 working day of the start date. If equipment is late, the IT Service Desk provides a loan device within 4 working hours of a request.

## 3. Access requests
Access to core systems (email, intranet, HR self-service, learning portal) is created automatically. Role-specific system access needs manager approval and is granted within 2 working days of approval.

## 4. Moves between roles
For internal moves, access is updated on the move date. Access from the previous role is removed within 5 working days unless the handover plan says otherwise.

## 5. Lost or damaged equipment
Report loss or damage to the IT Service Desk within 24 hours. A replacement is issued within 2 working days.
