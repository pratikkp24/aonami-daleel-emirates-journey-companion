# Facilities, Staff ID and Workspace Standard (FAC-10)
Synthetic sample policy for the prototype.

## 1. Staff ID card
The staff ID card is issued by day 2 of employment. Until then, a visitor pass is issued at reception. Lost cards are reported to Security and replaced within 1 working day.

## 2. Workspace
A workspace is allocated before the start date or move date by Facilities.

## 3. Parking and staff transport
Parking permits are issued on request within 3 working days. Staff transport routes are published on the intranet; registration takes 2 working days.

## 4. Housing for movers
For relocating employees, Facilities arranges company housing or temporary accommodation as approved under the Relocation Policy.
