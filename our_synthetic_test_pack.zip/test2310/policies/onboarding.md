# Onboarding Policy (ONB-01)
Synthetic sample policy for the prototype.

## 1. Purpose
Every new joiner should be ready to work from day 1, with equipment, access, identification and training arranged by named owners.

## 2. Before day 1
Talent Acquisition confirms the offer. Government Services starts the employment visa within 5 days of offer acceptance. IT orders the laptop and accounts at least 5 days before the start date.

## 3. Day 1 induction
HR Onboarding runs the induction on the start date. The joiner receives the welcome pack, meets their buddy and signs the code of conduct acknowledgement.

## 4. First week targets
The laptop is issued within 1 working day of the start date. The staff ID card is issued by day 2. System access is granted by day 3. Mandatory training is booked by day 5. If a target is missed, the joiner may raise it through the companion and the owning team must respond within 1 working day.

## 5. First month
The medical fitness test is completed by day 5 and the Emirates ID application by day 7. Payroll set-up, including bank details, is completed by day 10. The manager holds a buddy check-in by day 14 and a 30-day welcome conversation by day 30. The 30-day conversation is about settling in and support; it is not a performance review.

## 6. Probation
Probation lasts 6 months. Probation outcomes are decided by the line manager and HR through the performance process, outside the companion.
