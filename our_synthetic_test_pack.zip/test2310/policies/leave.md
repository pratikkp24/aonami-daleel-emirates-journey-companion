# Leave During Onboarding and Moves (HR-08)
Synthetic sample policy for the prototype.

## 1. Annual leave
Annual leave accrues from the start date. During probation, annual leave may be taken with the manager's approval.

## 2. Sick leave
Sick leave needs a medical certificate from the first day of absence and is reported to the manager the same day.

## 3. Leave around a move
Leave during the 10 days before a move date needs the agreement of both managers.

## 4. Travel to join
Joiners hired from outside the UAE receive a one-way joining ticket for themselves and eligible dependants.
