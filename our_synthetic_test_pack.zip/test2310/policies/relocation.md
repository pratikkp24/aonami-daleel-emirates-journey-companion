# Relocation Policy (MOB-04)
Synthetic sample policy for the prototype.

## 1. Eligibility
Relocation support applies to new joiners hired from outside the UAE and to internal moves that change the work location to another city or country.

## 2. Relocation allowance
A one-time relocation allowance is paid with the first salary in the new location: grades 1 to 6 AED 5,000; grades 7 to 9 AED 10,000; grade 10 and above AED 15,000. An extra AED 3,000 is paid when the employee relocates with family.

## 3. Shipping
Shipping of personal goods is covered up to 2 cubic metres for single employees and 5 cubic metres for families, through the approved mover.

## 4. Temporary accommodation
Temporary accommodation is provided for up to 14 nights for single employees and up to 30 nights for families, starting on arrival.

## 5. Approval and timing
Relocation is approved by the Mobility team at least 21 days before the move date. Housing is arranged at least 7 days before the move date.

## 6. Claims
Claims for relocation costs not paid directly must be submitted within 60 days of the move with receipts.
