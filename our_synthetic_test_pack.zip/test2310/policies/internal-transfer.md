# Internal Transfer Policy (MOB-05)
Synthetic sample policy for the prototype.

## 1. Eligibility
Employees may apply for an internal move after 12 months in their current role, or earlier with the agreement of both managers.

## 2. Approvals
A move needs approval from the current manager, the receiving manager and the HR business partner. The HR business partner approves within 15 days of the request.

## 3. Offer and start date
HR issues the new role letter, with the move date, grade and allowances, within 5 days of approval. The move date is normally at least 30 days after approval.

## 4. Release and handover
The current manager releases the employee on the agreed move date and agrees a handover plan, completed by the day before the move.

## 5. After the move
The receiving manager holds a welcome check-in within 7 days of the move date. Role training is booked within 5 days of the move date.

## 6. Pay changes
Changes to salary and allowances take effect from the move date and appear in the next payroll after the cut-off.
