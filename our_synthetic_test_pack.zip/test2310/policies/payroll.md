# Payroll and First Salary Procedure (PAY-09)
Synthetic sample policy for the prototype.

## 1. Bank details
Bank details must be entered in HR self-service by day 10 of employment. A salary certificate for opening a bank account is issued within 2 working days of request.

## 2. Pay date and cut-off
Salaries are paid on the 27th of each month. Changes received after the 20th are paid in the following month.

## 3. First salary
The first salary is paid for the days worked in the first month. If the start date is after the cut-off, the first salary is paid with the following month's salary.

## 4. Salary advance
If the first salary is delayed because of a company process, the employee may request an advance of up to 50% of monthly basic salary, paid within 3 working days.
