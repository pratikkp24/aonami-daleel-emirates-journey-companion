# Allowances Policy (PAY-06)
Synthetic sample policy for the prototype.

## 1. Housing allowance
Employees not in company accommodation receive a monthly housing allowance set by grade and location in their offer or role letter.

## 2. Transport allowance
A monthly transport allowance is paid to employees who are not eligible for staff transport.

## 3. Location allowance
Employees moving to an outstation location receive a location allowance from the move date while they work there.

## 4. Timing
Allowances start from the start date or move date. Changes received after the payroll cut-off on the 20th of the month are paid in the following month with arrears.

## 5. Queries
Allowance queries go to Payroll, which responds within 2 working days.
