# Wellbeing and Speak-Up Policy (HR-11)
Synthetic sample policy for the prototype.

## 1. Employee assistance
A confidential employee assistance programme is available 24 hours a day for personal, family and work concerns.

## 2. Raising a concern
Concerns about harassment, bullying, discrimination, safety or misconduct can be raised with the HR business partner, any manager or the confidential speak-up line. HR acknowledges within 24 hours.

## 3. Confidentiality
Concerns are handled confidentially and shared only with the people needed to resolve them. Retaliation against anyone raising a concern in good faith is not tolerated.

## 4. Urgent safety
If anyone is in immediate danger, contact Security or emergency services first.
