# Employee Companion: Use, Consent and Privacy (DIG-12)
Synthetic sample policy for the prototype.

## 1. Purpose
The companion helps employees through onboarding and internal moves. It works for the employee. It is not a monitoring tool for managers.

## 2. What it uses
The companion uses the employee's journey events, their own service requests and the published policies. Pulse feedback and comments are used only when the employee opts in, and stop being used as soon as consent is withdrawn.

## 3. What the employee can see
The employee can see everything the companion holds about them, every signal shared with their HR business partner, and every handoff made on their behalf. They can download it at any time.

## 4. What managers see
Managers see the progress of journey tasks for their own new joiners and movers. Managers never see conversations, pulse feedback or comments.

## 5. Human oversight
Any intervention that affects an employee goes through a named human owner. The companion drafts and routes; people decide.

## 6. No performance use
Companion data is never used for performance, probation, disciplinary or promotion decisions.

## 7. Retention
Conversations are kept for 90 days and pulse feedback for 12 months, then deleted. Employees may delete their pulse feedback at any time.
