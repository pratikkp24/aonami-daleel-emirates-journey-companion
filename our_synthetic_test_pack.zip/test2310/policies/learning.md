# Learning and Mandatory Training Policy (LRN-07)
Synthetic sample policy for the prototype.

## 1. Mandatory modules
All new joiners complete four mandatory modules: information security, data privacy, code of conduct and health and safety.

## 2. Booking
Mandatory training is booked by day 5 of employment. Classroom sessions run every Tuesday and Thursday; online modules are available at any time.

## 3. Completion
Mandatory training is completed within 30 days of the start date. Role training for internal moves is booked within 5 days of the move date.

## 4. Rebooking
A missed session can be rebooked once without manager approval. Further rebookings need manager approval.

## 5. Records
Completion is recorded in the learning portal and visible to the employee.
