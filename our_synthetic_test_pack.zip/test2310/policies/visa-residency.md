# Visa and Residency Procedure (GOV-03)
Synthetic sample policy for the prototype.

## 1. Sponsorship
The company sponsors the employment visa and residency for employees who require them, and pays all government fees.

## 2. Documents from the employee
The employee submits a passport copy valid for at least 6 months, a passport photo and an attested highest degree certificate within 5 days of the request. Missing documents pause the application, and the employee is told which document is missing.

## 3. Timelines
Government Services submits the visa application within 5 days of offer acceptance. Visa issue normally takes up to 18 days after submission. If the visa is not issued 7 days before the start date, Government Services informs the employee, the hiring manager and the HR business partner, and the start date may be moved.

## 4. After arrival
The medical fitness test is completed within 5 days of the start date. The Emirates ID application is submitted within 7 days of the start date, after the medical test. Residency stamping follows within 30 days of entry.

## 5. Dependants
Employees in grade 9 and above may sponsor a spouse and children under the company scheme. Applications are made after the employee's own residency is issued.

## 6. Status updates
Employees can ask for the status of their application at any time. Government Services updates the status within 1 working day of a query.
