# Journey maps
Synthetic sample for the prototype. Target day is counted from the start date (onboarding) or the move date (internal mobility). Negative numbers are days before.

## Onboarding
| Step | Event | Owner | Target day | Depends on | Applies to | Policy | Critical |
|---|---|---|---|---|---|---|---|
| O1 Offer accepted | offer_accepted | Talent Acquisition | -30 | | all | ONB-01 | |
| O2 Visa application submitted | visa_application_submitted | Government Services | -25 | O1 | visa | GOV-03 | yes |
| O3 Visa issued | visa_issued | Government Services | -7 | O2 | visa | GOV-03 | yes |
| O4 IT kit ordered | it_kit_ordered | IT Service Desk | -5 | O1 | all | IT-02 | |
| O5 Workspace allocated | workspace_allocated | Facilities | -2 | O1 | all | FAC-10 | |
| O6 Day 1 induction | induction_completed | HR Onboarding | 0 | | all | ONB-01 | |
| O7 IT kit issued | it_kit_issued | IT Service Desk | 1 | O4 | all | IT-02 | yes |
| O8 Staff ID issued | staff_id_issued | Facilities | 2 | O6 | all | FAC-10 | |
| O9 System access granted | system_access_granted | IT Service Desk | 3 | O7 | all | IT-02 | |
| O10 Medical test completed | medical_completed | Government Services | 5 | O3 | visa | GOV-03 | |
| O11 Mandatory training booked | training_booked | Learning | 5 | O6 | all | LRN-07 | |
| O12 Emirates ID applied | emirates_id_applied | Government Services | 7 | O10 | visa | GOV-03 | yes |
| O13 Payroll and bank set up | payroll_setup_completed | Payroll | 10 | O6 | all | PAY-09 | |
| O14 Buddy check-in | buddy_checkin | Manager | 14 | O6 | all | ONB-01 | |
| O15 Mandatory training completed | training_completed | Learning | 30 | O11 | all | LRN-07 | |
| O16 30-day welcome conversation | welcome_conversation_30 | Manager | 30 | O6 | all | ONB-01 | |

## Internal mobility
| Step | Event | Owner | Target day | Depends on | Applies to | Policy | Critical |
|---|---|---|---|---|---|---|---|
| M1 Move requested | transfer_requested | Manager | -45 | | all | MOB-05 | |
| M2 Move approved | transfer_approved | HR Onboarding | -30 | M1 | all | MOB-05 | yes |
| M3 New role letter issued | role_letter_issued | HR Onboarding | -25 | M2 | all | MOB-05 | |
| M4 Relocation approved | relocation_approved | Mobility | -21 | M2 | relocating | MOB-04 | yes |
| M5 Housing arranged | housing_arranged | Facilities | -7 | M4 | relocating | MOB-04 | yes |
| M6 Handover completed | handover_completed | Manager | -1 | M2 | all | MOB-05 | |
| M7 Access updated | access_updated | IT Service Desk | 0 | M2 | all | IT-02 | |
| M8 Payroll updated | payroll_updated | Payroll | 0 | M3 | all | PAY-06 | |
| M9 Role training booked | role_training_booked | Learning | 5 | M2 | all | LRN-07 | |
| M10 Welcome check-in | new_manager_checkin | Manager | 7 | M2 | all | MOB-05 | |

## Team owners
| Team | Named owner | Response time (days) |
|---|---|---|
| Talent Acquisition | Hessa Al Mansoori | 3 |
| Government Services | Omar Al Hashimi | 2 |
| IT Service Desk | Arjun Nair | 2 |
| Facilities | Daniel Okafor | 2 |
| HR Onboarding | Mariam Al Suwaidi | 2 |
| Learning | Grace Mendoza | 2 |
| Payroll | Fatima Rahman | 2 |
| Mobility | Sara Haddad | 3 |
| Manager | Line manager | 3 |
